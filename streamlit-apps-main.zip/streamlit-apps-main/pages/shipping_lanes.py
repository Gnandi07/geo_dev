import ee
import streamlit as st
import geemap.foliumap as geemap

# Get an NLCD image by year.
def shippingLanes(year):
    # Import the NLCD collection.
    dataset = ee.ImageCollection('COPERNICUS/S1_GRD')

    # Filter the collection by year.
    vh = dataset.filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
    vh = vh.filter(ee.Filter.eq('instrumentMode', 'IW'))
    vh = vh.filterDate(str(year) + '-01-01', str(year) + '-12-31')
    vhAscending = vh.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'))
    # Select the land cover band.
    water = ee.Image('ESA/GLOBCOVER_L4_200901_200912_V2_3')
    water = water.select('landcover')
    waterMask = water.eq(210)
    vhMaxA = vhAscending.select('VH').max()
    return vhMaxA.updateMask(waterMask)


st.header("Global Shipping Lanes (Sentinel-1)")

# Create a layout containing two columns, one for the map and one for the layer dropdown list.
row1_col1, row1_col2 = st.columns([3, 1])

# Create an interactive map
Map = geemap.Map(center=[40, -100], zoom=4)

# Select the seven NLCD epochs after 2000.
years = ["2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023"]

# Add a dropdown list and checkbox to the second column.
with row1_col2:
    selected_year = st.multiselect("Select a year", years)
    # add_legend = st.checkbox("Show legend")

# Add selected NLCD image to the map based on the selected year.
if selected_year:
    for year in selected_year:
        Map.setCenter(0, 0, 3)
        Map.addLayer(shippingLanes(year), {'min': -15, 'max': 0, 'palette': ['00008b', 'orange']}, "Lanes " + year)
    with row1_col1:
        Map.to_streamlit(height=600)

else:
    with row1_col1:
        Map.to_streamlit(height=600)
