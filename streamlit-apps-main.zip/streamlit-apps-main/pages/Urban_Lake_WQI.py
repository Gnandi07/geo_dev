import ee
import streamlit as st
import geemap.foliumap as geemap
import pandas as pd
import numpy as np
import altair as alt
import datetime as datetime
# import altair as alt

reReArgs = {
  'reducer': ee.Reducer.mean(),
  'geometry': ee.Geometry.Point([0, 0]),
  'scale': 100,
  'crs': 'EPSG:5070',
  'bestEffort': True,
  'maxPixels': 1e14,
  'tileScale': 0.1
  }

def regionReduce(img):
  eeDate = img.date()
  year = eeDate.get('year')
  month = eeDate.getRelative('month', 'year')
  doy = eeDate.getRelative('day', 'year')
  date = eeDate.format('YYYY-MM-dd')

  stat = img.reduceRegion(
    reducer = reReArgs['reducer'],
    geometry = reReArgs['geometry'],
    scale = reReArgs['scale'],
    crs = reReArgs['crs'],
    bestEffort = reReArgs['bestEffort'],
    maxPixels = reReArgs['maxPixels'],
    tileScale = reReArgs['tileScale'])

  return(ee.Feature(None, stat) \
    .copyProperties(img, img.propertyNames())
    .set({
      'DOY': doy,
      'Month': month,
      'Year': year,
      'Date': date}))

def getReReList(col, props):
  dict = col.map(algorithm = regionReduce).filter(ee.Filter.notNull(props)).reduceColumns(reducer = ee.Reducer.toList().repeat(len(props)),selectors = props)
  return(ee.List(dict.get('list')).getInfo())

def eeList2Df(list, cols):
  df = pd.DataFrame(list).transpose()
  df.columns = [k for k in cols.keys()]
  return(df.astype(cols))

def setTime(image):
  return ee.ImageCollection(ee.List(image.get('images'))).mosaic().set('system:time_start', ee.Date(image.get('date')).millis())

def formatTime(image):
  return image.set('date', image.date().format('yyyy-MM-dd'))

def getDailyMosaic(img_coll):
  img_coll = img_coll.map(algorithm = formatTime)

  daily = ee.ImageCollection(ee.Join.saveAll('images').apply(**{
      'primary': img_coll,
      'secondary': img_coll,
      'condition': ee.Filter.And(
          ee.Filter.equals(**{'leftField': 'date','rightField': 'date'}),
          ee.Filter.equals(**{'leftField': 'SPACECRAFT_NAME','rightField': 'SPACECRAFT_NAME'}),
          ee.Filter.equals(**{'leftField': 'SENSING_ORBIT_NUMBER','rightField': 'SENSING_ORBIT_NUMBER'})
          )
    })
  ).map(algorithm = setTime)
  daily = daily.sort('date',bool(1))
  #daily = daily.first()
  return daily

def getCover(image):
  pix = ee.Image(1).clip(AOI)
  totPixels = ee.Number(pix.reduceRegion(**{
      'reducer': ee.Reducer.count(),
      'scale': scale,
      #'maxPixels': 9999999,
      #'bestEffort': 'true',
      'geometry': AOI
  }).values().get(0))

  cldPixels = ee.Number(ee.Image(image.select('CloudMask')).reduceRegion(**{
      'reducer': ee.Reducer.sum(),
      'scale': scale,
      #'maxPixels': 9999999,
      #'bestEffort': 'true',
      'geometry': AOI
  }).values().get(0))

  actPixels = ee.Number(image.reduceRegion(**{
      'reducer': ee.Reducer.count(),
      'scale': scale,
      #'maxPixels': 9999999,
      #'bestEffort': 'true',
      'geometry': AOI
  }).values().get(0))

  percAoiCover = actPixels.divide(totPixels).multiply(100)
  percCldCover = cldPixels.divide(totPixels).multiply(100)
  image = image.set('actPixels', actPixels)
  image = image.set('cldPixels', cldPixels)
  image = image.set('totPixels', totPixels)
  image = image.set('AoiCover', percAoiCover)
  image = image.set('perCloud', percCldCover)
  return image

MAX_CLOUD_PROBABILITY = 85;

def maskClouds(img):
  clouds = ee.Image(img.get('cloud_mask')).select('probability')
  isCloud = clouds.gt(MAX_CLOUD_PROBABILITY)
  isCloud = isCloud.rename('CloudMask')
  img = img.addBands(isCloud)
  return img

def findLakes1(sat_img):
  ndwi = sat_img.normalizedDifference(['B3', 'B8'])
  lakes = ndwi.gt(0)
  lakes = lakes.updateMask(lakes)
  return lakes

def findLakes2(sat_img):
  MNDWI_threshold=0.42; #testing shows recommended 0.42 for Sentinel-2 and Landsat 8. For the scene in article [1] it was 0.8.
  NDWI_threshold=0.4; #testing shows recommended 0.4 for Sentinel-2 and Landsat 8. For the scene in article [1] it was 0.5.
  ndvi = sat_img.normalizedDifference(['B8', 'B4'])
  mndwi = sat_img.normalizedDifference(['B3', 'B11'])
  ndwi = sat_img.normalizedDifference(['B3', 'B8'])
  ndwi_leaves = sat_img.normalizedDifference(['B8', 'B11'])
  aweish = sat_img.expression(
    'B2 + (2.5 * B3) - (1.5 * (B8 + B11)) - (0.25 * B12)',
    {'B2': sat_img.select('B2'),
     'B3': sat_img.select('B3'),
     'B8': sat_img.select('B8'),
     'B11': sat_img.select('B11'),
     'B12': sat_img.select('B12')
    })
  aweinsh = sat_img.expression(
    '4 * (B3 - B11) - ((0.25 * B8) + (2.75 * B11))',
    {'B3': sat_img.select('B3'),
     'B8': sat_img.select('B8'),
     'B11': sat_img.select('B11')
    })
  dbsi = sat_img.normalizedDifference(['B11', 'B3'])
  dbsi = dbsi.subtract(ndvi)
  wii = (sat_img.select('B8').pow(2)).divide(sat_img.select('B4'))
  wri = sat_img.expression(
    '(B3 + B4)/(B8 + B11)',
    {'B3': sat_img.select('B3'),
     'B4': sat_img.select('B4'),
     'B8': sat_img.select('B8'),
     'B11': sat_img.select('B11')
    })
  puwi = sat_img.expression(
    '(5.83 * B3) - (6.57 * B4) - (30.32 * B8) + 2.25',
    {'B3': sat_img.select('B3'),
     'B4': sat_img.select('B4'),
     'B8': sat_img.select('B8')
    })
  uwi = sat_img.expression(
    '(B3 - (1.1 * B4) - (5.2 * B8) + 0.4)',
    {'B3': sat_img.select('B3'),
     'B4': sat_img.select('B4'),
     'B8': sat_img.select('B8')
    })
  uwi2 = sat_img.expression(
    'B3 - (1.1 * B4) - (5.2 * B8)',
    {'B3': sat_img.select('B3'),
     'B4': sat_img.select('B4'),
     'B8': sat_img.select('B8')
    })
  uwi = uwi.divide(uwi2.abs())
  usi = sat_img.expression(
    '(0.25 * (B3/B4)) - (0.57 * (B8/B3)) - (0.83 * (B2/B3)) + 1',
    {'B2': sat_img.select('B2'),
     'B3': sat_img.select('B3'),
     'B4': sat_img.select('B4'),
     'B8': sat_img.select('B8')
    })
  lakes = (mndwi.gt(MNDWI_threshold)).Or(
    ndwi.gt(NDWI_threshold)).Or(aweinsh.gt(0.1879)).Or(aweish.gt(0.1112)).Or(
      ndvi.lt(-0.2)).Or(ndwi_leaves.gt(1))
  lakes = lakes.And(((aweinsh.gt(-0.03)).And(dbsi.lte(0))).Not())
  lakes = lakes.updateMask(lakes)
  lakes = lakes.rename('lakes')
  return lakes

def calc_pixArea(sat,AOI):
  totPixels = ee.Number(sat.clip(AOI).reduceRegion(**{
    'reducer': ee.Reducer.count(),
    'scale': 10,
    'geometry': AOI,
  }).values().get(0)) 
  return totPixels.multiply(100).divide(1000000)

def calc_geomArea(feat):
  pix = ee.Image(1).clip(feat)
  totPixels = ee.Number(pix.reduceRegion(**{
    'reducer': ee.Reducer.count(),
    'scale': 10,
    'geometry': feat,
    }).values().get(0))
  return totPixels.multiply(100).divide(1000000)

def findLakeArea(img):
  osm_lakes = ee.Image(1)
  osm_lakes = osm_lakes.clip(AOI)
  plakes = findLakes2(img)
  lakes = findLakes1(img)
  lakes = (plakes.unmask()).Or(lakes.unmask())
  int_lakes = (lakes.unmask()).And(osm_lakes)
  int_lakes = int_lakes.updateMask(int_lakes)
  act_area = calc_pixArea(int_lakes, AOI)
  extent = calc_geomArea(AOI)
  openArea = act_area.divide(extent).multiply(100)
  img = img.set('Extent',extent)
  img = img.set('Actual',act_area)
  img = img.set('openWater',openArea)
  chl_a = calc_chla(img).clip(AOI).rename('CHL_A')
  cyano = calc_cya(img).clip(AOI).rename('Cya_a')
  turb = calc_turb(img).clip(AOI).rename('Turb')
  img = img.addBands(chl_a).addBands(cyano).addBands(turb)
  return img

def findImg(aoi,date1,date2,watBodsFeat):
  
  #date1: Previous Year
  sat_img1 = ee.ImageCollection("COPERNICUS/S2_SR")
  start_date1 = date1.advance(-1,'day')
  stop_date1 = date1.advance(1,'day')
  sat_img1 = sat_img1.filter(ee.Filter.date(start_date1,stop_date1)).median().clip(aoi)
  osm_lakes = ee.Image(1)
  osm_lakes = osm_lakes.clip(watBodsFeat)
  plakes = findLakes2(sat_img1)
  lakes = findLakes1(sat_img1)
  lakes = (plakes.unmask()).Or(lakes.unmask())
  int_lakes1 = (lakes.unmask()).And(osm_lakes)
  int_lakes1 = int_lakes1.updateMask(int_lakes1).rename('LakeBounds_1')
  lake_vectors1 = int_lakes1.reduceToVectors(**{
    'geometry': aoi,
    'scale': 10,
    'eightConnected': True,
    'geometryType': 'polygon',
    'labelProperty': 'Boundary',
  })

  # boxcar = ee.Kernel.square(**{
  #   'radius': 2, 'units': 'pixels', 'magnitude': 1
  # })
  boxcar = ee.Kernel.gaussian(**{'radius': 3})
  chl_a = calc_chla(sat_img1).clip(lake_vectors1).convolve(boxcar).rename('Chlorophyll_a_1')
  cyano = calc_cya(sat_img1).clip(lake_vectors1).convolve(boxcar).rename('Cyanobacteria_1')
  turb = calc_turb(sat_img1).clip(lake_vectors1).convolve(boxcar).rename('Turbidity_1')

  sat_img = sat_img1.select(['B4','B3','B2'])
  sat_img = sat_img.addBands(chl_a)
  sat_img = sat_img.addBands(cyano)
  sat_img = sat_img.addBands(turb)
  sat_img = sat_img.addBands(int_lakes1)
  # lk_w_chla = watBodsFeat.map(algorithm=addWAQ)

  sat_img2 = ee.ImageCollection("COPERNICUS/S2_SR")
  start_date2 = date2.advance(-1,'day')
  stop_date2 = date2.advance(1,'day')
  sat_img2 = sat_img2.filter(ee.Filter.date(start_date2,stop_date2)).median().clip(aoi)
  osm_lakes = ee.Image(1)
  osm_lakes = osm_lakes.clip(watBodsFeat)
  plakes = findLakes2(sat_img2)
  lakes = findLakes1(sat_img2)
  lakes = (plakes.unmask()).Or(lakes.unmask())
  int_lakes2 = (lakes.unmask()).And(osm_lakes)
  int_lakes2 = int_lakes2.updateMask(int_lakes2).rename('LakeBounds_2')
  lake_vectors2 = int_lakes2.reduceToVectors(**{
    'geometry': aoi,
    'scale': 10,
    'eightConnected': True,
    'geometryType': 'polygon',
    'labelProperty': 'Boundary',
  })

  chl_a = calc_chla(sat_img2).clip(lake_vectors2).convolve(boxcar).rename('Chlorophyll_a_2')
  cyano = calc_cya(sat_img2).clip(lake_vectors2).convolve(boxcar).rename('Cyanobacteria_2')
  turb = calc_turb(sat_img2).clip(lake_vectors2).convolve(boxcar).rename('Turbidity_2')

  sat_img = sat_img.addBands(chl_a)
  sat_img = sat_img.addBands(cyano)
  sat_img = sat_img.addBands(turb)
  sat_img = sat_img.addBands(int_lakes2)

  sat_img = sat_img.addBands(sat_img2.select('B4').rename('B4_2'))
  sat_img = sat_img.addBands(sat_img2.select('B3').rename('B3_2'))
  sat_img = sat_img.addBands(sat_img2.select('B2').rename('B2_2'))

  return sat_img

def calc_chla(sat_img):
  chl = sat_img.expression(
  'B3/B1',
  {'B1': sat_img.select('B1'),
   'B3': sat_img.select('B3')
  })
  chl = chl.rename('CHL_A')
  chl = chl.pow(3.94)
  chl = chl.expression(
  '4.26 * CHL',
  {'CHL': chl.select('CHL_A')
  })
  return chl

def calc_cya(sat_img):
  cya = sat_img.expression(
  'B3 * B4 / B2',
  {'B2': sat_img.select('B2'),
   'B3': sat_img.select('B3'),
   'B4': sat_img.select('B4')
  })
  cya = cya.rename('CYA')
  cya = cya.pow(2.38)
  cya = cya.expression(
  '115530.31 * CYA',
  {'CYA': cya.select('CYA')
  })
  return cya.divide(1000000000)

def calc_turb(sat_img):
  turb = sat_img.expression(
  '8.93 * (B3/B1) - 6.39',
  {'B1': sat_img.select('B1'),
   'B3': sat_img.select('B3')
  })
  turb = turb.rename('TURB')
  return turb

def addWAQ(lake_feat):
  shape = lake_feat.geometry();
  meanChlA1 = ee.Number(img.select('Chlorophyll_a_1').reduceRegion(**{
    'reducer': ee.Reducer.mean(),
    'scale': 10,
    'geometry': shape,
  }).values().get(0))
  meanChlA2 = ee.Number(img.select('Chlorophyll_a_2').reduceRegion(**{
    'reducer': ee.Reducer.mean(),
    'scale': 10,
    'geometry': shape,
  }).values().get(0))
  
  meanCya1 = ee.Number(img.select('Cyanobacteria_1').reduceRegion(**{
    'reducer': ee.Reducer.mean(),
    'scale': 10,
    'geometry': shape,
    }).values().get(0))
  meanCya2 = ee.Number(img.select('Cyanobacteria_2').reduceRegion(**{
    'reducer': ee.Reducer.mean(),
    'scale': 10,
    'geometry': shape,
    }).values().get(0))

  meanTurb1 = ee.Number(img.select('Turbidity_1').reduceRegion(**{
    'reducer': ee.Reducer.mean(),
    'scale': 10,
    'geometry': shape,
    }).values().get(0))  
  meanTurb2 = ee.Number(img.select('Turbidity_2').reduceRegion(**{
    'reducer': ee.Reducer.mean(),
    'scale': 10,
    'geometry': shape,
    }).values().get(0))
  
  geoCentroid = shape.centroid(**{'maxError': 1}).coordinates()
  
  osm_area = calc_geomArea(lake_feat.geometry());
  curr_area1 = calc_pixArea(img.select('LakeBounds_1'),shape);
  curr_area2 = calc_pixArea(img.select('LakeBounds_2'),shape);
  
  lake_feat = lake_feat.set('Mean Chl_A_1', meanChlA1) #Unit: mg/m3
  lake_feat = lake_feat.set('Mean Cyanobacteria_1', meanCya1)  #Unit: 10^3 cells/ml
  lake_feat = lake_feat.set('Mean Turbidity_1', meanTurb1) #Unit: NTU
  lake_feat = lake_feat.set('Current Area_1', curr_area1)  #Unit: km^2
  lake_feat = lake_feat.set('Mean Chl_A', meanChlA2) #Unit: mg/m3
  lake_feat = lake_feat.set('Mean Cyanobacteria', meanCya2)  #Unit: 10^3 cells/ml
  lake_feat = lake_feat.set('Mean Turbidity', meanTurb2) #Unit: NTU
  lake_feat = lake_feat.set('Current Area', curr_area2)  #Unit: km^2
  lake_feat = lake_feat.set('OSM Area', osm_area) #Unit: km^2
  lake_feat = lake_feat.set('Centroid', geoCentroid)
  return lake_feat

# boxcar = ee.Kernel.square(**{
#   'radius': 3, 'units': 'pixels', 'magnitude': 1
# })

# chl_a = calc_chla(img).clip(lake_vectors).convolve(boxcar)
# cyano = calc_cya(img).clip(lake_vectors).convolve(boxcar)
# turb = calc_turb(img).clip(lake_vectors).convolve(boxcar)

# Visualization parameters
vis = {
  'min': 500,
  'max': 4000,
  'bands': ['B4_2', 'B3_2', 'B2_2'] # select on Red, Green & Blue bands for display
}

waq_palette = ['496FF2' , '82D35F' , 'FEFD05' , 'FD0004' , '8E2026' , 'D97CF5']

chla_vis = {
  'min': 0,
  'max': 50,
  'palette': waq_palette
}

cya_vis = {
  'min': 2400, #0,
  'max': 16500, #100,
  'palette': waq_palette
}

turb_vis = {
  'min': 1, #0,
  'max': 8, #20,
  'palette': waq_palette
}

lon = float(77.5946)
lat = float(12.9716)
radius = 10
aoi = ee.Geometry.Point([lon, lat]).buffer(1000*radius).bounds()

lakecollection = ee.FeatureCollection('projects/ee-adithyapani/assets/blr_lakes-polygon')
not_drain = lakecollection.filter('water != "drain"')
watBods = not_drain;
watBods = watBods.filter('Name != ""')
watBods = watBods.filterBounds(aoi)

img = findImg(aoi,ee.Date('2024-05-07'),ee.Date('2023-04-18'),watBods)
lake_vectors = img.select('LakeBounds_2').reduceToVectors(**{
    'geometry': aoi,
    'scale': 10,
    'eightConnected': True,
    'geometryType': 'polygon',
    'labelProperty': 'Boundary',
  })
print('Number of Water Bodies (OSM): ', watBods.size().getInfo())

s2LakesCount = lake_vectors.size().getInfo()
print('Number of lakes detected from S2 image: ', s2LakesCount)

lk_w_chla = watBods.map(algorithm=addWAQ)
lk_w_chla = lk_w_chla.select(['Name','Mean Chl_A', 'Mean Cyanobacteria','Mean Turbidity', 'OSM Area', 'Current Area',
                              'Mean Chl_A_1', 'Mean Cyanobacteria_1','Mean Turbidity_1', 'Current Area_1', 'Centroid'])
detections = lk_w_chla.size().getInfo()
print('Lakes detected: ', detections)
lakeList = lk_w_chla.toList(detections)
min_lake_area = 0.001;
lk_w_chla = lk_w_chla.filter(ee.Filter.gt('OSM Area', min_lake_area))

lake_subset = lk_w_chla.select(['Name','Mean Chl_A', 'Mean Cyanobacteria','Mean Turbidity', 'OSM Area', 'Current Area',
                                'Mean Chl_A_1', 'Mean Cyanobacteria_1','Mean Turbidity_1', 'Current Area_1'])
lakes_df = ee.data.computeFeatures({
    'expression': lake_subset,
    'fileFormat': 'PANDAS_DATAFRAME'
})

lakes_df['OSM Area'] = lakes_df['OSM Area']*100
lakes_df['Current Area'] = lakes_df['Current Area']*100
lakes_df['Current Area_1'] = lakes_df['Current Area_1']*100
lakes_df['Open Area'] = lakes_df['Current Area']*100/lakes_df['OSM Area']
lakes_df['Open Area_1'] = lakes_df['Current Area_1']*100/lakes_df['OSM Area']

newDf = lakes_df['Name']
lake_names = np.array(newDf)

Map = geemap.Map(center=[lat, lon], zoom=12)
Map1 = geemap.Map(center=[lat, lon], zoom=13)

skyserve_logo = "images/skyserve_combination_white.png"
st.logo(
    skyserve_logo,
    link="https://skyserve.ai/",
    icon_image=None
)

st.title("Urban LakeSights")
tab1, tab2, tab3 = st.tabs(["Overview Stats", "Spatial Analysis", "Historical Insights"])

tabHeight = 650

with tab1:
  tab1Col1, tab1Col2 = st.columns((3, 2), gap='medium')
  with tab1Col1:
    st.header('All City Lakes')
    Map1.addLayer(img, vis, 'S2 True Colour')
    Map1.addLayer(watBods, {'color': 'blue'}, 'Water Bodies')
    Map1.to_streamlit(height=tabHeight)
    st.caption('Data credits: ESA Copernicus Sentinel | OpenStreeMap | SkyServe')
  with tab1Col2:
      with st.container():
        tab1Col2ContCol1, tab1Col2ContCol2, tab1Col2ContCol3 = st.columns((1, 1, 1), gap='small')
        with tab1Col2ContCol1:
          st.metric(label="Lakes of record", value=detections, help="Number of lakes as per Land Records")
        with tab1Col2ContCol2:
          st.metric(label="Water bodies detected", value=s2LakesCount, help="Detected from latest satellite image")
        with tab1Col2ContCol3:
          totOpenWater = lakes_df['Current Area'].sum()*100/lakes_df['OSM Area'].sum()
          st.metric(label="Open-water Lake Area", value="{:.0f}%".format(totOpenWater), help="Ratio of total current area of all lakes to the total official lake extent")
      dispDf = lakes_df[['Name','OSM Area','Current Area','Mean Chl_A', 'Mean Cyanobacteria','Mean Turbidity']]
      # st.dataframe(dispDf)
      st.dataframe(
        dispDf,
        height=tabHeight,
        column_config={
            "Name": "Lake",
            "OSM Area": "Area (ha)",
            "Current Area": "Extent (ha)",
            "Mean Chl_A": "Chlorophyll a",
            "Mean Cyanobacteria": "Cyanobactera-A",
            "Mean Turbidity": "Turbidity"
        },
        hide_index=True,
    )
with tab2:
  tab2Col1, tab2Col2 = st.columns((3, 2), gap='medium', vertical_alignment="center")
  with tab2Col2:
    selected_lake = st.selectbox("Select a Lake", lake_names,index=None,
      placeholder="No lake selected..",)

  if selected_lake:
    print(selected_lake)
    targetLake = lakes_df.loc[lakes_df['Name'] == selected_lake]
    # targetLake.head(1)
    actArea = targetLake.iloc[0, targetLake.columns.get_loc('OSM Area')]
    curArea = targetLake.iloc[0, targetLake.columns.get_loc('Current Area')]
    meanChlA = targetLake.iloc[0, targetLake.columns.get_loc('Mean Chl_A')]
    deltaChlA = meanChlA - targetLake.iloc[0, targetLake.columns.get_loc('Mean Chl_A_1')]
    meanCyanA = targetLake.iloc[0, targetLake.columns.get_loc('Mean Cyanobacteria')]
    deltaCyanA = meanCyanA - targetLake.iloc[0, targetLake.columns.get_loc('Mean Cyanobacteria_1')]
    meanTurb = targetLake.iloc[0, targetLake.columns.get_loc('Mean Turbidity')]
    deltaTurb = meanTurb - targetLake.iloc[0, targetLake.columns.get_loc('Mean Turbidity_1')]
    opArea = targetLake.iloc[0, targetLake.columns.get_loc('Open Area')]
    deltaOpArea = opArea - targetLake.iloc[0, targetLake.columns.get_loc('Open Area_1')]

    if opArea >0:
      geoString = ee.Feature(targetLake.iloc[0, targetLake.columns.get_loc('geo')]).geometry()
      nameString = ee.String(targetLake.iloc[0, targetLake.columns.get_loc('Name')]).getInfo()
      Map.centerObject(geoString)
      Map.addLayer(img, vis, 'S2 True Colour')
      Map.addLayer(geoString, {'color': 'blue'}, nameString)
      Map.addLayer(img.select('Chlorophyll_a_2').clip(geoString), chla_vis, 'Chlorophyll A Concentration')
      Map.addLayer(img.select('Cyanobacteria_2').clip(geoString), cya_vis, 'Cyanobacteria Density')
      Map.addLayer(img.select('Turbidity_2').clip(geoString), turb_vis, 'Turbidity')
      with tab2Col1:
        st.subheader(f"Monitoring :red[{selected_lake}]")
        Map.to_streamlit(height=tabHeight)
      with tab2Col2:
        tab2Col2Col1, tab2Col2Col2 = st.columns((1, 1), gap='small', vertical_alignment="center")
        with tab2Col2Col1:
          st.metric(label="Lake Area", value="{:.1f} ha".format(actArea))
        with tab2Col2Col2:
          st.metric(label="Current Area", value="{:.1f} ha".format(curArea))
        with st.container(border=True):
          st.subheader("Change over 1 year", divider="red")
          tab2Col2ContCol1, tab2Col2ContCol2 = st.columns((1, 1), gap='medium', vertical_alignment="center")
          with tab2Col2ContCol1:
            st.metric(label="Open Water", value="{:.0f}%".format(opArea),
                      delta="{:.0f}%".format(deltaOpArea), help="Ratio of current area of open-surface water to the official lake extent")
            st.metric(label="Chlorophyll a (mg/m3)", value="{:.1f}".format(meanChlA),
                      delta="{:.1f}".format(deltaChlA),delta_color="inverse", help="Chl_a levels indicate algae blooms. High levels mean excess nutrients and low dissolved oxygen, harming aquatic life.")
          with tab2Col2ContCol2:
            st.metric(label="Cyanobacteria-A (10^5 cells)", value="{:.0f}".format(meanCyanA),
                      delta="{:.0f}".format(deltaCyanA),delta_color="inverse", help="The density of Cyanobacteria measures the toxicity on urban water bodies. Lower the better.")
            st.metric(label="Turbidity (NTU)", value="{:.1f}".format(meanTurb),
                      delta="{:.1f}".format(deltaTurb),delta_color="inverse", help="Turbidity measures water cloudiness. WHO recommends below 5 NTU (ideal <1 NTU).")
    else:
      geoString = ee.Feature(targetLake.iloc[0, targetLake.columns.get_loc('geo')]).geometry()
      nameString = ee.String(targetLake.iloc[0, targetLake.columns.get_loc('Name')]).getInfo()
      Map.centerObject(geoString)
      Map.addLayer(img, vis, 'S2 True Colour')
      Map.addLayer(geoString, {'color': 'blue'}, nameString)
      with tab2Col1:
        st.subheader(f"Monitoring :red[{selected_lake}]")
        Map.to_streamlit(height=tabHeight)
      with tab2Col2:
        st.metric(label="Lake Status", value="Dried Up")

  else:
    with tab2Col1:
      st.header('City Lake Monitor')
      Map.addLayer(img, vis, 'S2 True Colour')
      Map.addLayer(watBods, {'color': 'blue'}, 'Water Bodies')
      Map.to_streamlit(height=600)

  with tab2Col1:
    st.caption('Data credits: ESA Copernicus Sentinel | OpenStreeMap | SkyServe')
with tab3:
  tab3Col1, tab3Col2 = st.columns((2, 2), gap='medium')
  with tab3Col1:
    selected_lake1 = st.selectbox("Select a Lake", lake_names,index=None, key="Tab3",
                  placeholder="No lake selected..",)
    maxPerCloud = st.slider("Pick max permissible clouds above lake (lower better)", 0, 75, 5)
    
  with tab3Col2:
    selected_year1 = "2024"
    selected_year1 = st.multiselect("Pick a year", ["2019", "2020", "2021", "2022", "2023", "2024"], placeholder="No selection")
    # param_options = {
    #       'openWater': '0',
    #       'CHL_A': '1',
    #       'Cya_a': '2',
    #       'Turb': '3'
    #       }
    param_options = {
          0: 'Open Water',
          1: 'Chlorophyll a',
          2: 'Cyanobacteria-A',
          3: 'Turbidity'
          }
    # selected_param = st.selectbox("Select a parameter", ['openWater', 'CHL_A', 'Cya_a', 'Turb'], index=None,
    #               placeholder="No parameter selected..",)
    tab3Col2Col1, tab3Col2Col2 = st.columns((2, 2), gap='medium', vertical_alignment="bottom")
    with tab3Col2Col1:
      # selected_param = st.selectbox(label="Select a parameter", options= ['openWater', 'CHL_A', 'Cya_a', 'Turb'], format_func=lambda x: param_options.get(x),)
      selected_param = st.selectbox(label="Select a parameter", options= [0, 1, 2, 3], format_func=lambda x: param_options.get(x),)
      print('Param: ', selected_param)
    with tab3Col2Col2:
      buttonState = st.button("Request Data", type="primary")
      print('Param: ', selected_param)

  if selected_lake1:
    targetLake1 = lakes_df.loc[lakes_df['Name'] == selected_lake1]
    print('Selected Lake: ', selected_lake1)
    geoString1 = ee.Feature(targetLake1.iloc[0, targetLake1.columns.get_loc('geo')]).geometry()
    # print('geostring: ', geoString1)
    AOI = geoString1
    selected_year1 = [int(numeric_string) for numeric_string in selected_year1]
    start_date = str(min(selected_year1)) + '-01-01'
    stop_date = str(max(selected_year1)) + '-12-31'
    print('Duration to filter: ', start_date, ' to ', stop_date)

    if buttonState:
        minAoiCover = 95
        scale = 10
        # maxPerCloud = 10
        # limitOutputsFlag = 'false'
        # maxResults = 5
        reReArgs['scale'] = 10
        reReArgs['reducer'] = ee.Reducer.mean()
        reReArgs['geometry'] = geoString1
        reReArgs['crs'] = 'EPSG:4326'

        Sen2 = ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED").filter(ee.Filter.date(start_date, stop_date)).filterBounds(geoString1)
        s2Clouds = ee.ImageCollection('COPERNICUS/S2_CLOUD_PROBABILITY').filter(ee.Filter.date(start_date, stop_date)).filterBounds(geoString1)

        s2SrWithCloudMask = ee.Join.saveFirst('cloud_mask').apply(**{
          'primary': Sen2,
          'secondary': s2Clouds,
          'condition': ee.Filter.equals(**{'leftField': 'system:index', 'rightField': 'system:index'})
        })

        datasetCloudMasked = ee.ImageCollection(s2SrWithCloudMask).map(algorithm = maskClouds)
        datasetCloudMasked = getDailyMosaic(datasetCloudMasked)
        datasetCloudMasked = datasetCloudMasked.map(algorithm = getCover)

        queriedOutput = datasetCloudMasked.filter(ee.Filter.gte('AoiCover', minAoiCover))
        print('Results with AOI >= ', minAoiCover,'%: ',queriedOutput.size().getInfo())
        queriedOutput = queriedOutput.filter(ee.Filter.lt('perCloud', maxPerCloud))
        filteredResults2 = queriedOutput.size().getInfo()
        print('Results with Cloud cover < ', maxPerCloud,'%: ',filteredResults2)

        # if limitOutputsFlag == 'true':
        #   filteredResults2 = maxResults

        filteredDataset = queriedOutput.limit(filteredResults2,'system:time_start')
        print('Number of cloud filtered & sorted results: ', filteredDataset.size().getInfo())

        result = filteredDataset.map(algorithm = findLakeArea)
        # print('Extent: ', filteredDataset.first().get('Extent').getInfo())
        # print('Actual: ', filteredDataset.first().get('Actual').getInfo())
        result = result.select('CHL_A', 'Cya_a', 'Turb')
        lakeDataList = getReReList(result, ['Year', 'Month', 'DOY', 'Date', 'Extent', 'Actual', 'openWater', 'CHL_A', 'Cya_a', 'Turb'])
        lakeColumns = {'Year': int, 'Month': int, 'DOY': int, 'Date': str, 'Extent': float, 'Actual': float, 'openWater': float, 'CHL_A': float, 'Cya_a': float, 'Turb': float}
        snLakeDf = eeList2Df(lakeDataList, lakeColumns)
        snLakeDf['Month'] = snLakeDf['Month'] + 1
        # print(snLakeDf.head(5))
        yLabels = ['openWater', 'CHL_A', 'Cya_a', 'Turb']
        print(yLabels[selected_param])
        yTitles = ["Open Water (perc of Extent)", "Chlorophyll a (mg/m3)", "Cyanobacteria-A (x10^5 cells)", "Turbidity (NTU)"]
        print(yTitles[selected_param])
        yMode = yLabels[selected_param] + ''':Q'''
        print(yMode)
        c = (
              alt.Chart(snLakeDf).mark_line().encode(
                alt.X('DOY:O', title='Day of Year'),
                # alt.Y('openWater:Q', title='Open Water (perc of Extent)', scale=alt.Scale(domain=(min(snLakeDf['openWater']), max(snLakeDf['openWater'])))),
                alt.Y(str(yMode), title=str(yTitles[selected_param]), scale=alt.Scale(domain=(min(snLakeDf[str(yLabels[selected_param])]), max(snLakeDf[str(yLabels[selected_param])])))),
                alt.Color('Year:O', scale=alt.Scale(scheme="dark2")),
                tooltip=[
                  alt.Tooltip('Year:O', title='Year'),
                  alt.Tooltip('DOY:O', title='DOY'),
                  alt.Tooltip(str(yMode), title='Open Water')
                ]
              ).interactive() #.properties(width=1500, height=700)
        )
        st.altair_chart(c, use_container_width = True)
    else:
        st.write("Goodbye")
  else:
    st.write("Goodbye")
        
footer_html = """<div style='text-align: center;'>
  <p>Developed with ❤️ at <a href="https://earthsights.skyserve.ai/">SkyServe</a></p>
</div>"""
st.markdown(footer_html, unsafe_allow_html=True)
